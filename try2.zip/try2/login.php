<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $otp = $_POST['otp'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password']) && $user['otp'] == $otp) {
            $_SESSION['user'] = $user;
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Invalid credentials. Please try again.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <title>Login</title>
    <style>
        body {
            background-color: #f4f4f4;
        }

        .container {
            margin-top: 20px;
        }

        .login-box {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 0 auto;
        }

        .status {
            text-align: center;
        }

        hr {
            border-color: #ddd;
        }

        label {
            display: inline-block;
            width: 30%;
            margin-bottom: 10px;
        }

        input {
            width: 65%;
            padding: 8px;
            margin-bottom: 10px;
        }

        .btn-container {
            text-align: center;
        }

        .btn {
            width: 50%;
            background-color: #28a745;
            color: #fff;
            margin-top: 10px;
        }

        .forgot-password {
            text-align: center;
            margin-top: 15px;
        }

        .forgot-password a {
            text-decoration: underline;
            color: #007bff;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-box">
            <div class="status">
                <h3>Login Page</h3>
            </div>
            <hr>
            <div class="f1 login-form">
                <form method="post" action="">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br>
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required><br>
                    <label for="otp">OTP:</label>
                    <input type="text" id="otp" name="otp" required><br>
                    <div class="btn-container">
                        <button type="submit" name="login" class="btn btn-success">Login</button>
                    </div>
                </form>

                <div class="btn-container">
                    <button onclick="window.location.href='registration_form.php'" class="btn btn-primary mt-2">Register</button>
                    <button type="button" onclick="window.location.href='resendotp.php'" class="btn btn-warning mt-2">Resend OTP ?</button>
                </div>

                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot password?</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
