<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database Connection Error: " . $e->getMessage();
    exit;
}

if (isset($_POST['accept'])) {
    $email = $_POST['email'];
    $rawPassword = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email");
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($rawPassword, $user['password'])) {
            $newOTP = rand(1000, 9999);
            $updateStmt = $pdo->prepare("UPDATE otp_verify SET otp = :newOTP WHERE email = :email");
            $updateStmt->bindParam(':newOTP', $newOTP, PDO::PARAM_INT);
            $updateStmt->bindParam(':email', $email, PDO::PARAM_STR);
            $updateStmt->execute();
            require 'vendor/autoload.php';
            

            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Username = 'greenyauction@gmail.com';
            $mail->SMTPSecure = 'tls';
            $mail->Password = 'drqn coud gnbd ksfg';
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAuth = true;
            $mail->Port = 587;
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ];
            $mail->setFrom('greenyauction@gmail.com', 'Admin');
            $mail->addAddress($email);
            $mail->Subject = 'New OTP Verification';
            $mail->Body = "Your new OTP is: $newOTP";
            $mail->SMTPDebug = 0;
            $mail->Debugoutput = function ($str, $level) {
            echo "debug level $level; message: $str";
            };
            
          
            sleep(1);
            if ($mail->send()) {
                echo "OTP resent successfully.";
            } else {
                echo "Error sending OTP to email. Please try again. Error: " . $mail->ErrorInfo;
            }
        } else {
            echo "Invalid email or password. Please try again.";
        }
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <title>Resend OTP</title>
    <style>
        body {
            background-color: #f4f4f4;
        }

        .container {
            margin-top: 20px;
        }

        .resend-box {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 0 auto;
        }

        label {
            display: inline-block;
            width: 30%;
            margin-bottom: 10px;
        }

        input {
            width: 65%;
            padding: 8px;
            margin-bottom: 10px;
        }

        .btn-container {
            text-align: center;
        }

        .btn {
            width: 50%;
            background-color: #ffc107;
            color: #fff;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="resend-box">
            <h3>Resend OTP</h3>
            <form method="post" action="">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required><br>
                <div class="btn-container">
                    <button type="submit" name="accept" class="btn btn-warning">Accept</button>
                    <button type="button" onclick="window.location.href='login.php'" class="btn btn-secondary">Back to Login</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
