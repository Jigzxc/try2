
<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $otp = rand(1000, 9999);
    $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email");
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    
   
    try {
        $insertStmt = $pdo->prepare("INSERT INTO otp_verify (name, email, phone, gender, password, otp) VALUES (:name, :email, :phone, :gender, :password, :otp)");
        $insertStmt->bindParam(':name', $name);
        $insertStmt->bindParam(':email', $email);
        $insertStmt->bindParam(':phone', $phone);
        $insertStmt->bindParam(':gender', $gender);
        $insertStmt->bindParam(':password', $password);
        $insertStmt->bindParam(':otp', $otp);
        $insertStmt->execute();
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'greenyauction@gmail.com';
        $mail->Password = 'drqn coud gnbd ksfg';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->SMTPDebug = 2;
        $mail->Debugoutput = function ($str, $level) {
            echo "debug level $level; message: $str";
        };
        $mail->setFrom('greenyauction@gmail.com', 'Admin');
        $mail->addAddress($email);
        $mail->Subject = 'OTP Verification';
        $mail->Body = "Your OTP is: $otp";
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
            ],
        ];

        if ($mail->send()) {
            echo "Redirecting to Login Page";
            error_log("Redirecting to Login Page");
            header("Location: login.php");
            exit();
        } else {
            echo "Error sending OTP to email. Please try again.";
            error_log("Error sending OTP to email.");
        }
        
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
}

?>