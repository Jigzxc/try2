<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_POST['verify'])) {
    $enteredOTP = implode("", $_POST['otp']);
    $email = $_SESSION['email']; // Assuming you stored the email in the session during signup

    try {
        $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email AND otp = :otp");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':otp', $enteredOTP);
        $stmt->execute();
        $count = $stmt->rowCount();

        if ($count > 0) {
            // OTP is correct, you can proceed with saving the signup data to the database
            // Retrieve signup data from the session or database
            $signupData = $_SESSION['signup_data']; // Change this accordingly

            // Save signup data to the database
            $insertStmt = $pdo->prepare("INSERT INTO your_signup_table (name, email, phone, gender, password) VALUES (:name, :email, :phone, :gender, :password)");
            $insertStmt->bindParam(':name', $signupData['name']);
            $insertStmt->bindParam(':email', $signupData['email']);
            $insertStmt->bindParam(':phone', $signupData['phone']);
            $insertStmt->bindParam(':gender', $signupData['gender']);
            $insertStmt->bindParam(':password', $signupData['password']);
            $insertStmt->execute();

            echo "Signup successful!";
        } else {
            echo "Invalid OTP. Please try again.";
        }
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input {
            width: 40px;
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form method="post" action="">
        <h2>Enter OTP to Verify</h2>
        <label for="otp1">OTP:</label>
        <input type="text" id="otp1" name="otp[]" maxlength="1" required>
        <input type="text" id="otp2" name="otp[]" maxlength="1" required>
        <input type="text" id="otp3" name="otp[]" maxlength="1" required>
        <input type="text" id="otp4" name="otp[]" maxlength="1" required>
        <br>
        <button type="submit" name="verify">Verify</button>
    </form>
</body>
</html>
