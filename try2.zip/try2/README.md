# Sign up and Login using OTP Verification

This is an Industrial Live Research Project where I made a sign-up and login page using OTP message verification system.

## API
I used a free API of the OTP message gateway service provided by [2factor](https://2factor.in/).

## Author
[Adhiraj](https://github.com/adhirajcs)
